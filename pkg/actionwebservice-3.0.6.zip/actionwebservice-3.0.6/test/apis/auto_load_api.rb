# encoding: UTF-8
class AutoLoadAPI < ActionWebService::API::Base
  api_method :void
end
