# encoding: UTF-8
require 'action_web_service'
