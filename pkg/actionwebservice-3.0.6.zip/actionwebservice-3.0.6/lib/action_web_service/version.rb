# encoding: UTF-8
module ActionWebService
  module VERSION #:nodoc:
    MAJOR = 3
    MINOR = 0
    TINY  = 6

    STRING = [MAJOR, MINOR, TINY].join('.')
  end
end
